package starter.posting;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CreatePost {

    @When("I write the status at my home page")
    public void i_write_the_status_at_my_home_page() {
    }

    @And("I clicked {string} box")
    public void i_clicked_start_a_post_box(String string)  {
    }

    @And("It was taken to the create a post")
    public void it_was_taken_to_the_create_a_post() {
    }

    @And("I wrote the comment in the box {string}")
    public void i_wrote_the_comment_in_the_box_What_Do_You_Want_To_Talk_About(String string)  {
    }

    @And("Before I posted my status I could choice who could read my post")
    public void before_i_posted_my_status_i_could_choice_who_could_read_my_post() {
    }

    @And("Before I posted my status I could add hastag")
    public void before_i_posted_my_status_i_could_add_hastag() {
    }

    @And("Before I posted my status I could add photo,video,document, and etc")
    public void before_i_posted_my_status_i_could_add_photo_video_document_and_etc() {
    }

    @Then("My post has been in my new post")
    public void my_post_has_been_in_my_new_post() {
    }
}
