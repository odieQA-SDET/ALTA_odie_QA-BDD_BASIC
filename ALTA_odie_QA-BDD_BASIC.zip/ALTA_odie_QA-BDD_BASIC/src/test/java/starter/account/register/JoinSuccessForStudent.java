package starter.account.register;

import io.cucumber.java.en.And;


public class JoinSuccessForStudent {
    @And("I filled my data as Student is like School or College or University and etc correctly")
    public void i_filled_my_data_as_student_is_like_school_or_college_or_university_and_etc_correctly() {
    }
}