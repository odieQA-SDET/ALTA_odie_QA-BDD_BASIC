package starter.account.register;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class JoinSuccessProfessional {

        @Given("I was on the register page")
        public void i_was_on_the_register_Page() {
            // Write code here that turns the phrase above into concrete actions
            // throw new cucumber.api.PendingException();
            System.out.println("==> Yeah..!! You Success Join Now");
        }

        @When("I filled my email or phone number and password correctly")
        public void i_filled_my_email_or_phone_number_and_password_correctly() {
            // Write code here that turns the phrase above into concrete actions
            //throw new cucumber.api.PendingException();

        }

        @When("I filled my first name and last name")
        public void i_filled_my_first_name_and_last_name() {
            // Write code here that turns the phrase above into concrete actions
            //throw new cucumber.api.PendingException();
        }

        @When("I did security verification pop up correctly")
        public void i_did_security_verification_pop_up_correctly() {
            // Write code here that turns the phrase above into concrete actions
            //throw new cucumber.api.PendingException();
        }

        @When("I filled my country and city")
        public void i_filled_my_country_and_city() {
            // Write code here that turns the phrase above into concrete actions
            //throw new cucumber.api.PendingException();
        }

        @When("I filled my data of job")
        public void i_filled_my_data_of_job() {
            // Write code here that turns the phrase above into concrete actions
            //throw new cucumber.api.PendingException();
        }

        @When("I filled the code from my email that has sent by linkedin")
        public void i_filled_the_code_from_my_email_that_has_sent_by_linkedin() {
            // Write code here that turns the phrase above into concrete actions
            //throw new cucumber.api.PendingException();
        }

        @Then("I was taken to the dashboard home success")
        public void i_was_taken_to_the_dashboard_home_success() {
            // Write code here that turns the phrase above into concrete actions
            //throw new cucumber.api.PendingException();

        }
}
